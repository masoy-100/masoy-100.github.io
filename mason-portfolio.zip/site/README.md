# masonrathore portfolio

Static site. No build step. Works on GitHub Pages, Netlify, or any static host.

## Files
- `index.html` — content and structure
- `css/site.css` — styles
- `js/config.js` — email, API key, which tickers to chart (edit this first)
- `js/app.js` — visual effects, nav, DSS demo, copy email
- `js/markets.js` — market data fetching, stats, and Chart.js rendering

## Deploy to GitHub Pages
1. Delete the old `index.html` from your `username.github.io` repo.
2. Upload everything in this folder (keep the `css/` and `js/` folders intact).
3. Pages redeploys automatically in about a minute.

## Live data
- Crypto (BTC, SOL) loads from CoinGecko's public API with no key.
- ETFs (SPY, QQQ, GLD) need a free Alpha Vantage key. Paste it into `js/config.js`. Without a key the ETF section shows sample data and says so on screen. Free tier is 25 requests a day, and the site caches responses for 10 minutes per visitor, so it's fine for a portfolio.
- Add or swap tickers in `js/config.js`.

## Placeholders
Search `class="fill"` in `index.html` for the yellow spots to replace (dates, repo links, stack items).
